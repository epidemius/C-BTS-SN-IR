int verifTab(int n,int tab[]){
int i;
printf("la fonction fonctionne");
for(i=0; i<n; i++){
    if(tab[i]%2==0)
    {
    printf("%d \n", tab[i]);
    }
}
}
